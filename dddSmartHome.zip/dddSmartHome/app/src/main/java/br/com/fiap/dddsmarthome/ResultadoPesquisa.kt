package br.com.fiap.dddsmarthome

data class ResultadoPesquisa(val cidade: String, val estado: String)
