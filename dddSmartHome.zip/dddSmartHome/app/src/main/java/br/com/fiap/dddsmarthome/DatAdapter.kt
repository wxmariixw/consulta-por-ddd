package br.com.fiap.dddsmarthome

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DatAdapter : RecyclerView.Adapter<DatAdapter.ResultadoViewHolder>() {

    private var resultados: List<ResultadoPesquisa> = listOf()

    fun atualizarDados(novaLista: List<ResultadoPesquisa>) {
        resultados = novaLista
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultadoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_resultado, parent, false)
        return ResultadoViewHolder(view)
    }

    override fun onBindViewHolder(holder: ResultadoViewHolder, position: Int) {
        holder.bind(resultados[position])
    }

    override fun getItemCount(): Int {
        return resultados.size
    }

    class ResultadoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cidadeTextView: TextView = itemView.findViewById(R.id.textCidade)
        private val estadoTextView: TextView = itemView.findViewById(R.id.textEstado)

        fun bind(resultado: ResultadoPesquisa) {
            cidadeTextView.text = resultado.cidade
            estadoTextView.text = resultado.estado
        }
    }
}
