package br.com.fiap.dddsmarthome

class DbHelper(mainActivity2: MainActivity2) {

}
