# Aplicação Web

## Tecnologias Utilizadas

### Linguagem

- Python
- HTML
- CSS
- Javascript

### Framework

- Flask

### Bibliotecas

- Pandas
- SQLalchemy
- pydantic
- JSON

### Banco de dados

- PostgreSQL